Chor Sipahi Raja Mantri aur Pyada - online multiplayer package (Name + ID)

How to run:
1. Extract the zip.
2. In project folder run:
   npm install
   npm start
3. Open http://localhost:3000 in browser.
4. Open 5 tabs/devices, enter Name + ID (e.g. "बिकु सर" and "001"), Join and Start Game.

Notes:
- Requires Node.js installed.
- Speech uses browser's SpeechSynthesis.
