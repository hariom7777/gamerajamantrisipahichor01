const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

const MAX_PLAYERS = 5;
const TOTAL_ROUNDS = 20;
const ROLE_POINTS = { "Raja": 1000, "Mantri": 800, "Sipahi": 500, "Pyada": 200, "Chor": 0 };
const BONUS = 500;

let lobbyPlayers = []; // { socketId, id, name }
let gameState = null;

function resetGame() {
  gameState = { round: 0, totalRounds: TOTAL_ROUNDS, players: {}, order: [], lastRaja: null };
}

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
}

io.on("connection", (socket) => {
  console.log("connected:", socket.id);

  socket.on("joinLobby", ({ id, name }) => {
    if (lobbyPlayers.find(p => p.id === id)) {
      socket.emit("joinFailed", "ID already in lobby");
      return;
    }
    lobbyPlayers.push({ socketId: socket.id, id, name });
    socket.data.playerId = id;
    socket.data.playerName = name;
    io.emit("lobbyUpdate", lobbyPlayers.map(p => ({ id: p.id, name: p.name })));
    console.log("Lobby:", lobbyPlayers.map(p => p.id + ":" + p.name));
  });

  socket.on("leaveLobby", () => {
    lobbyPlayers = lobbyPlayers.filter(p => p.socketId !== socket.id);
    io.emit("lobbyUpdate", lobbyPlayers.map(p => ({ id: p.id, name: p.name })));
  });

  socket.on("startGame", () => {
    if (lobbyPlayers.length !== MAX_PLAYERS) {
      socket.emit("startFailed", "Need exactly " + MAX_PLAYERS + " players to start");
      return;
    }
    resetGame();
    gameState.order = lobbyPlayers.map(p => p.id);
    for (const p of lobbyPlayers) {
      gameState.players[p.id] = { socketId: p.socketId, points: 0, currentRole: null, name: p.name };
    }
    io.emit("gameStarted", { order: gameState.order, totalRounds: TOTAL_ROUNDS, names: lobbyPlayers.reduce((a,c)=>{a[c.id]=c.name;return a;},{}) });
    setTimeout(() => startNextRound(), 800);
  });

  socket.on("rajaMessage", ({ text }) => {
    if (!gameState) return;
    const sender = socket.data.playerId;
    if (!sender) return;
    if (gameState.players[sender] && gameState.players[sender].currentRole === "Raja") {
      io.emit("rajaMessage", { rajaId: sender, text, rajaName: gameState.players[sender].name });
    }
  });

  socket.on("sipahiGuess", ({ round, sipahiId, suspectId }) => {
    if (!gameState || gameState.round !== round) return;
    const roles = {};
    for (const pid of Object.keys(gameState.players)) roles[pid] = gameState.players[pid].currentRole;
    const actualChor = Object.keys(roles).find(pid => roles[pid] === "Chor");
    if (!actualChor) return;
    if (suspectId === actualChor) {
      gameState.players[sipahiId].points += BONUS;
      io.emit("roundResult", { round, result: "correct", sipahiId, suspectId, updatedPoints: getPublicPointsSnapshot() });
    } else {
      gameState.players[actualChor].points += BONUS;
      io.emit("roundResult", { round, result: "wrong", sipahiId, suspectId, actualChor, updatedPoints: getPublicPointsSnapshot() });
    }

    setTimeout(() => {
      if (gameState.round >= gameState.totalRounds) {
        io.emit("gameEnded", { finalScores: getPublicPointsSnapshot() });
        lobbyPlayers = [];
        gameState = null;
        io.emit("lobbyUpdate", lobbyPlayers.map(p => ({ id: p.id, name: p.name })));
      } else {
        startNextRound();
      }
    }, 1200);
  });

  socket.on("disconnect", () => {
    console.log("disconnect", socket.id);
    lobbyPlayers = lobbyPlayers.filter(p => p.socketId !== socket.id);
    io.emit("lobbyUpdate", lobbyPlayers.map(p => ({ id: p.id, name: p.name })));
    if (gameState) {
      const pid = socket.data.playerId;
      if (pid && gameState.players[pid]) {
        io.emit("gameEnded", { finalScores: getPublicPointsSnapshot(), reason: "player disconnected" });
        lobbyPlayers = [];
        gameState = null;
        io.emit("lobbyUpdate", lobbyPlayers.map(p => ({ id: p.id, name: p.name })));
      }
    }
  });
});

function getPublicPointsSnapshot() {
  const out = {};
  for (const pid in gameState.players) {
    out[pid] = { points: gameState.players[pid].points, role: (gameState.players[pid].currentRole === "Raja" || gameState.players[pid].currentRole === "Sipahi") ? gameState.players[pid].currentRole : undefined, name: gameState.players[pid].name };
  }
  return out;
}

function startNextRound() {
  if (!gameState) return;
  const previousRaja = gameState.lastRaja;
  gameState.round += 1;
  const round = gameState.round;

  const pids = Object.keys(gameState.players);
  const rolesPool = ["Raja","Mantri","Sipahi","Pyada","Chor"];
  shuffle(rolesPool);
  shuffle(pids);

  let newRaja = null;
  for (let i = 0; i < pids.length; i++) {
    const pid = pids[i];
    const role = rolesPool[i];
    gameState.players[pid].currentRole = role;
    gameState.players[pid].points += ROLE_POINTS[role];
    if (role === "Raja") newRaja = pid;
  }
  gameState.lastRaja = newRaja;

  const publicReveal = {};
  for (const pid of pids) {
    const role = gameState.players[pid].currentRole;
    publicReveal[pid] = (role === "Raja" || role === "Sipahi") ? role : "Secret";
  }

  io.emit("roundStarted", {
    round,
    totalRounds: gameState.totalRounds,
    rolesPublic: publicReveal,
    previousRaja: previousRaja,
    order: gameState.order,
    points: getPublicPointsSnapshot()
  });

  for (const pid of pids) {
    const sockId = gameState.players[pid].socketId;
    const role = gameState.players[pid].currentRole;
    io.to(sockId).emit("yourRole", { role, name: gameState.players[pid].name });
  }

  if (newRaja) {
    io.emit("rajaAnnounce", { rajaId: newRaja, text: "Sipahi! Chor ko pakaro!", rajaName: gameState.players[newRaja].name });
  }
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log("Server listening on", PORT));
