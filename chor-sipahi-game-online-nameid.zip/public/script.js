const socket = io();
let myId = null;
let myName = null;
let myRole = null;
let currentRound = 0;
let totalRounds = 20;
let sipahiTimer = null;
let sipahiCountdown = 20;
let playerOrder = [];

const playersList = document.getElementById("playersList");
const joinBtn = document.getElementById("joinBtn");
const leaveBtn = document.getElementById("leaveBtn");
const startBtn = document.getElementById("startBtn");
const playerIdInput = document.getElementById("playerIdInput");
const playerNameInput = document.getElementById("playerNameInput");

const lobbySection = document.getElementById("lobbySection");
const gameSection = document.getElementById("gameSection");
const finalSection = document.getElementById("finalSection");

const envelopesDiv = document.getElementById("envelopes");
const tableArea = document.getElementById("tableArea");
const yourRoleSpan = document.getElementById("yourRole");
const sipahiActions = document.getElementById("sipahiActions");
const guessList = document.getElementById("guessList");
const timerProgress = document.getElementById("timerProgress");
const roundInfo = document.getElementById("roundInfo");
const scoreList = document.getElementById("scoreList");
const finalScores = document.getElementById("finalScores");
const winnerDiv = document.getElementById("winner");
const backToLobby = document.getElementById("backToLobby");

const ROLE_ICON = { "Raja":"👑", "Mantri":"🧠", "Sipahi":"🛡️", "Pyada":"👞", "Chor":"🕵️" };

joinBtn.onclick = () => {
  const id = playerIdInput.value.trim();
  const name = playerNameInput.value.trim() || "Player";
  if (!id) return alert("Enter ID like 001");
  myId = id;
  myName = name;
  socket.emit("joinLobby", { id, name });
  joinBtn.style.display = "none";
  leaveBtn.style.display = "inline-block";
};

leaveBtn.onclick = () => {
  socket.emit("leaveLobby");
  joinBtn.style.display = "inline-block";
  leaveBtn.style.display = "none";
  myId = null;
  myName = null;
};

startBtn.onclick = () => {
  socket.emit("startGame");
};

socket.on("lobbyUpdate", (players) => {
  playersList.innerHTML = "";
  players.forEach(p=>{
    const li = document.createElement("li");
    li.textContent = `${p.name} - ${p.id}`;
    playersList.appendChild(li);
  });
  startBtn.disabled = !(players.length === 5);
});

socket.on("gameStarted", (data) => {
  lobbySection.style.display = "none";
  gameSection.style.display = "block";
  totalRounds = data.totalRounds || 20;
  playerOrder = data.order || [];
  setupPlayerCards(playerOrder, data.names || {});
});

// create player cards on table
function setupPlayerCards(order, names) {
  tableArea.innerHTML = "";
  const positions = [
    {left: "6%", top: "12%"},
    {left: "70%", top: "12%"},
    {left: "6%", top: "68%"},
    {left: "70%", top: "68%"},
    {left: "38%", top: "4%"}
  ];
  for (let i=0;i<order.length;i++){
    const pid = order[i];
    const pos = positions[i] || {left:"40%", top:"40%"};
    const displayName = names[pid] || pid;
    const card = document.createElement("div");
    card.className = "player-card";
    card.id = "card-" + pid;
    card.style.left = pos.left;
    card.style.top = pos.top;
    card.innerHTML = `<div class="icon" id="icon-${pid}">❓</div><div class="label"><div class="pname">${displayName}</div><div class="pid">${pid}</div><div class="prole" id="role-${pid}">Secret</div></div>`;
    tableArea.appendChild(card);
  }
}

socket.on("roundStarted", (data) => {
  currentRound = data.round;
  roundInfo.textContent = `Round: ${currentRound} / ${data.totalRounds}`;
  updateScoreboard(data.points);
  if (data.previousRaja) animateRajaThrow(data.previousRaja, data.rolesPublic, data.order);
  else revealPublicRoles(data.rolesPublic);
});

// receive your private role and name
socket.on("yourRole", (data) => {
  myRole = data.role;
  yourRoleSpan.textContent = `${myRole} (${data.name || myName || ''})`;
  const roleEl = document.getElementById("role-" + myId);
  const iconEl = document.getElementById("icon-" + myId);
  if (roleEl) roleEl.textContent = myRole;
  if (iconEl) iconEl.textContent = ROLE_ICON[myRole] || "❓";

  if (myRole === "Raja") showRajaSpeakButton();
  else removeRajaSpeakButton();

  if (myRole === "Sipahi") {
    const others = Array.from(document.querySelectorAll('.player-card')).map(c=>c.id.replace('card-','')).filter(x=>x!==myId);
    showSipahiActions(others);
  } else {
    sipahiActions.style.display = "none";
    clearSipahiTimer();
  }
});

socket.on("rajaAnnounce", (data) => {
  displayRajaMessage(data.rajaId, data.text, data.rajaName);
});
socket.on("rajaMessage", (data) => {
  displayRajaMessage(data.rajaId, data.text, data.rajaName || data.rajaId);
});

function displayRajaMessage(rajaId, text, rajaName) {
  const announ = document.createElement("div");
  announ.className = "raja-annonce";
  announ.textContent = `${rajaName} (Raja): ${text}`;
  document.body.appendChild(announ);
  setTimeout(()=> announ.remove(), 3000);
  if ('speechSynthesis' in window) {
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'hi-IN';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  }
}

function showRajaSpeakButton() {
  removeRajaSpeakButton();
  const btn = document.createElement("button");
  btn.id = "rajaSpeakBtn";
  btn.textContent = "Raja: Speak";
  btn.onclick = () => {
    const text = prompt("Enter message to announce (default will be 'Sipahi! Chor ko pakaro!')") || "Sipahi! Chor ko pakaro!";
    socket.emit("rajaMessage", { text });
  };
  const timerArea = document.getElementById("timerArea");
  timerArea.appendChild(btn);
}
function removeRajaSpeakButton() { const ex = document.getElementById("rajaSpeakBtn"); if (ex) ex.remove(); }

function animateRajaThrow(rajaId, rolesPublic, order) {
  const rajaCard = document.getElementById("card-" + rajaId);
  if (!rajaCard) { revealPublicRoles(rolesPublic); return; }
  const rect = rajaCard.getBoundingClientRect();
  const parentRect = envelopesDiv.parentElement.getBoundingClientRect();
  const startLeft = rect.left - parentRect.left + rect.width/2;
  const startTop = rect.top - parentRect.top + rect.height/2;
  envelopesDiv.innerHTML = "";
  const pids = Object.keys(rolesPublic);
  pids.forEach((pid, idx) => {
    const env = document.createElement("div");
    env.className = "envelope";
    env.id = "env-" + pid;
    envelopesDiv.appendChild(env);
    env.style.left = startLeft + "px";
    env.style.top = startTop + "px";
  });
  pids.forEach((pid, idx) => {
    const targetCard = document.getElementById("card-" + pid);
    const env = document.getElementById("env-" + pid);
    if (!targetCard || !env) return;
    const tRect = targetCard.getBoundingClientRect();
    const tLeft = tRect.left - parentRect.left + tRect.width/2;
    const tTop = tRect.top - parentRect.top + tRect.height/2;
    gsap.to(env, {duration: 0.9, delay: 0.25*idx, left: tLeft, top: tTop, rotation: 360, ease: "power2.out", onComplete: () => {
      const roleText = rolesPublic[pid] === "Secret" ? "Secret" : rolesPublic[pid];
      const icon = ROLE_ICON[rolesPublic[pid]] || "❓";
      const roleEl = document.getElementById("role-" + pid);
      const iconEl = document.getElementById("icon-" + pid);
      if (roleEl) roleEl.textContent = roleText;
      if (iconEl) iconEl.textContent = (roleText === "Secret") ? "✉️" : icon;
      gsap.from("#card-" + pid, {scale:0.95, duration:0.25});
      setTimeout(()=> { try{ env.remove(); }catch(e){} }, 500);
    }});
  });
}

function revealPublicRoles(rolesPublic) {
  for (const pid in rolesPublic) {
    const roleDisplay = rolesPublic[pid] === "Secret" ? "Secret" : rolesPublic[pid];
    const icon = ROLE_ICON[rolesPublic[pid]] || "❓";
    const roleEl = document.getElementById("role-" + pid);
    const iconEl = document.getElementById("icon-" + pid);
    if (roleEl) roleEl.textContent = roleDisplay;
    if (iconEl) iconEl.textContent = (roleDisplay === "Secret") ? "✉️" : icon;
  }
}

// round result
socket.on("roundResult", (data) => {
  if (data.result === "correct") {
    showTempAlert(`Round ${data.round}: Sipahi guessed correctly!`);
  } else {
    showTempAlert(`Round ${data.round}: Sipahi guessed wrong. Chor (${data.actualChor||data.suspectId}) got 500 pts`);
  }
  updateScoreboard(data.updatedPoints);
});

// update scoreboard helper (public points + name for Raja/Sipahi)
function updateScoreboard(pointsSnapshot) {
  scoreList.innerHTML = "";
  const entries = Object.keys(pointsSnapshot).sort();
  entries.forEach(pid=>{
    const li = document.createElement("li");
    const namePart = pointsSnapshot[pid].name ? ` ${pointsSnapshot[pid].name} -` : "";
    const roleText = pointsSnapshot[pid].role ? ` (${pointsSnapshot[pid].role})` : "";
    li.textContent = `${pid}${namePart} ${pointsSnapshot[pid].points} pts${roleText}`;
    scoreList.appendChild(li);
  });
}

// show sipahi choices + timer
function showSipahiActions(others) {
  sipahiActions.style.display = "block";
  guessList.innerHTML = "";
  others.forEach(pid=>{
    const btn = document.createElement("button");
    btn.textContent = pid;
    btn.onclick = ()=> {
      makeGuess(pid);
    };
    guessList.appendChild(btn);
  });
  sipahiCountdown = 20;
  timerProgress.style.width = "100%";
  clearSipahiTimer();
  sipahiTimer = setInterval(()=>{
    sipahiCountdown--;
    const pct = (sipahiCountdown/20)*100;
    timerProgress.style.width = pct + "%";
    if (sipahiCountdown <= 0) {
      clearSipahiTimer();
      const pick = others[Math.floor(Math.random()*others.length)];
      makeGuess(pick);
    }
  }, 1000);
}

function clearSipahiTimer(){
  if (sipahiTimer) { clearInterval(sipahiTimer); sipahiTimer = null; }
}

// send guess to server
function makeGuess(suspectId) {
  clearSipahiTimer();
  socket.emit("sipahiGuess", { round: currentRound, sipahiId: myId, suspectId });
  sipahiActions.style.display = "none";
}

// game ended
socket.on("gameEnded", (data) => {
  gameSection.style.display = "none";
  finalSection.style.display = "block";
  finalScores.innerHTML = "";
  const pts = data.finalScores || data;
  let best = { pid: null, points: -1 };
  for (const pid in pts) {
    const li = document.createElement("li");
    li.textContent = `${pid} - ${pts[pid].points} pts`;
    finalScores.appendChild(li);
    if (pts[pid].points > best.points) {
      best = { pid, points: pts[pid].points };
    }
  }
  winnerDiv.textContent = `Winner: ${best.pid} 🎉`;
});

backToLobby.onclick = () => {
  finalSection.style.display = "none";
  lobbySection.style.display = "block";
  window.location.reload();
};

function showTempAlert(msg) {
  const a = document.createElement("div");
  a.className = "temp-alert";
  a.textContent = msg;
  document.body.appendChild(a);
  setTimeout(()=> a.remove(), 2500);
}
